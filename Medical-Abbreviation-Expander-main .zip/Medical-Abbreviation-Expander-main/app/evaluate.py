import pandas as pd
from sklearn.metrics import precision_score, accuracy_score

def evaluate_model(pred_file="data/analysis_data.csv", truth_file="data/ground_truth.csv"):
    # Load predicted expansions
    preds = pd.read_csv(pred_file)
    truth = pd.read_csv(truth_file)

    # Align predictions and ground truth by abbreviation
    merged = pd.merge(preds, truth, on="abbr", how="inner")

    if merged.empty:
        print("⚠️ No matching abbreviations between predictions and ground truth.")
        return

    # Binary correctness column
    merged["correct"] = merged.apply(lambda x: 1 if x["expansion"].strip().lower() == x["true_expansion"].strip().lower() else 0, axis=1)

    # Metrics
    precision = merged["correct"].sum() / len(merged) if len(merged) > 0 else 0
    accuracy = accuracy_score(merged["correct"], [1]*len(merged))

    print("📊 Evaluation Results:")
    print(f"Total Samples Evaluated: {len(merged)}")
    print(f"✅ Precision: {precision:.3f}")
    print(f"🎯 Accuracy: {accuracy:.3f}")

    # Optional — save results
    merged.to_csv("data/evaluation_results.csv", index=False)
    print("💾 Saved detailed results to data/evaluation_results.csv")
