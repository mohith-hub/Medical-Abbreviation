from models.resolver import AbbreviationResolver
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), '..', 'data')
CSV_PATH = os.path.join(DATA_DIR, 'abbreviations.csv')


def test_lookup_unambiguous():
    resolver = AbbreviationResolver(csv_path=CSV_PATH)
    assert resolver.lookup('BP') == ['Blood Pressure']
    chosen, conf = resolver.resolve('BP')
    assert chosen == 'Blood Pressure'
    assert conf > 0.9


def test_lookup_ambiguous():
    resolver = AbbreviationResolver(csv_path=CSV_PATH)
    # RA has two expansions per CSV: 'Rheumatoid Arthritis or Right Atrium'
    # The resolver currently splits on '|' to separate multiple expansions, but
    # the CSV uses ' or ' — so this test verifies that ambiguous entries are
    # handled as a single string (current behavior) and returned with lower confidence.
    candidates = resolver.lookup('RA')
    assert isinstance(candidates, list)
    assert len(candidates) >= 1
    chosen, conf = resolver.resolve('RA')
    assert isinstance(chosen, str)
    assert 0.0 <= conf <= 1.0
